#include<iostream>
using namespace std;
int main(){
cout <<"    ';-.          ----'                     " <<endl;
cout <<"      '.'!-....-/' .-''    '                            " <<endl;
cout <<"        !        /       '  '-.              " <<endl;
cout <<"        /()   () !     .      -           " <<endl;
cout <<"       |)  .    ()!   /    -.'                  " <<endl;
cout <<"        |  -'-     ,;  '.  <                     " <<endl;
cout <<"        ; .--    ,;|    >  |                   " <<endl;
cout <<"       / ,    /  , | .<'  -'                      " <<endl;
cout <<"      (_/     (_/  |                          " <<endl;
cout <<"       !       ,    ;-'                    " <<endl;
cout <<"         >     !   /                     " <<endl;
cout <<"        (_,-'' >  '                    " <<endl;
cout <<"          (-,'                            " <<endl;
    return 0;
}