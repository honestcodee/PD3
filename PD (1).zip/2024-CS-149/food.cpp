#include<iostream>
using namespace std;
int main(){
cout <<"     *        *        *               " <<endl;  
cout <<"       *        *        *               " <<endl;  
cout <<"         *        *        *              " <<endl;  
cout <<"       *        *        *            " <<endl;  
cout <<"     *        *        *              " <<endl;  
cout <<"      *        *         *             " <<endl;  
cout <<"       *         *         *          " <<endl;  
cout <<"************************************                                    " <<endl;  
cout <<" *                                *   " <<endl;  
cout <<"  *                             *     " <<endl;  
cout <<"    *                         *        " <<endl;  
cout <<"      *                     *          " <<endl;  
cout <<"        ******************               " <<endl;  
cout <<"WELCOME TO FOODIE APPLICATION              " <<endl;  
    return 0;
}