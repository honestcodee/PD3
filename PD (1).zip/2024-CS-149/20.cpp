#include<iostream>
using namespace std;
int main(){
    system("color 58");
 cout << ".....                  @@@@@      @@@@@                        " <<endl;
 cout << "......                @      @   @     @        ..........     " <<endl;
 cout << ".......                   @@@    @     @        .........      " <<endl;
 cout << "........                @@       @     @        ........       " <<endl;
 cout << "  .......             @@         @     @        .......        " <<endl;
 cout << "    ......           @@@@@@@@@    @@@@@  th     ......         " <<endl;
 cout << "      .....          ......................     .....          " <<endl;
 cout << "        ....           C E N T U R Y            ....          " <<endl;
 cout << "         ....        ......................     ...           " <<endl;
 cout << "          ...        @@@@ @@@@ @    @  @@@@     ..           " <<endl;
  cout << "           ..        @   @@@@  @  @    @       ..           " <<endl;
 cout << "         __||__       @   @      @      @     __||__          " <<endl;
 cout << "________|______|___   @   @@@@ @   @    @  __|______|________  " <<endl;

    return 0;
}