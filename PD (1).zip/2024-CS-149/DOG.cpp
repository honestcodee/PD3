#include<iostream>
using namespace std;
int main(){
cout <<" ------------------------------------        " <<endl;    
cout <<"              ^   ^                      " <<endl;    
cout <<"       o       ___                         " <<endl;    
cout <<"              (oo)\_____________           " <<endl;    
cout <<"         o    (__)\             )\/\         " <<endl;    
cout <<"                  ||------w                  " <<endl;    
cout <<"                  ||         |         " <<endl;    
cout <<"                  ||          ||        " <<endl;    
    return 0;
}