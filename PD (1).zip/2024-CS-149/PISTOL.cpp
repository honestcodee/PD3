#include<iostream>
using namespace std;
int main(){
cout <<"+--^------------ ---------- ------- ----------^--                                  " <<endl;  
cout <<"  |  |||||||||  '----------'-      '|           'o     " <<endl;  
cout <<"  '+--------------------------------^------------        " <<endl;  
cout <<"   ' ---------- ------------ ----------------'          " <<endl;  
cout <<"    ' / XXXXXXX'/ |        '/'                       " <<endl;  
cout <<"     / XXXXXXX'/  |         /'                  " <<endl;  
cout <<"    / XXXXXXX'/'--------- '                 " <<endl;  
cout <<"   / XXXXXXX'/                                 " <<endl;  
cout <<"  / XXXXXXX'/                                  " <<endl;  
cout <<" (_________(                                   " <<endl;  
cout <<"  '------'                                  " <<endl;  
cout <<"                                    " <<endl;  
cout <<"                                    " <<endl;  
cout <<"                                    " <<endl;  
    return 0;
}