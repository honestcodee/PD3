#include<iostream>
using namespace std;
int main(){
int a,b;
cout<<"enter the 1st integer"<<endl;
cin>>a;
b+=a;
cout<<"enter the 2nd integer"<<endl;
cin>>a;
b+=a;
cout<<"enter the 3rd integer"<<endl;
cin>>a;
b+=a;
cout<<"enter the 4th integer"<<endl;
cin>>a;
b+=a;
cout<<"enter the 5th integer"<<endl;
cin>>a;
b+=a;
cout<<"the sum of five integers is"<<b;


return 0;
}