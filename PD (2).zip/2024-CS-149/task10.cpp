#include<iostream>
using namespace std;
int main(){
int n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,op;
cout<<"Number 1:"<<endl;
cin>>n1;
cout<<"Number 2:"<<endl;
cin>>n2;
cout<<"Number 3:"<<endl;
cin>>n3;
cout<<"Number 4:"<<endl;
cin>>n4;
cout<<"Number 5:"<<endl;
cin>>n5;
cout<<"Number 6:"<<endl;
cin>>n6;
cout<<"Number 7:"<<endl;
cin>>n7;
cout<<"Number 8:"<<endl;
cin>>n8;
cout<<"Number 9:"<<endl;
cin>>n9;
cout<<"Number 10:"<<endl;
cin>>n10;
cout<<"Number 11:"<<endl;
cin>>n11;
cout<<"Number 12:"<<endl;
cin>>n12;
cout<<"Number 13:"<<endl;
cin>>n13;
cout<<"Number 14:"<<endl;
cin>>n14;
cout<<"Number 15:"<<endl;
cin>>n15;
op=((n1+n2+n3+n4+n5)+(n6*n7*n8*n9*n10))-(n11-n12-n13-n14-n15);
    cout<<"operation"<<op;
    return 0;
}